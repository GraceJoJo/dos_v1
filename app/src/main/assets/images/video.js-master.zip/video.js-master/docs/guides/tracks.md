# Tracks
There are currently three types of tracks

* [AudioTracks](./audio-tracks.md) - allows the selection of alternative AudioTracks for a video
* [VideoTracks](./video-tracks.md) - allows the selection of an alternative VideoTrack for a video
* [TextTracks](./text-tracks.md) - Text Tracks are used to display subtitles and captions, and add a menu for navigating between chapters in a video.
